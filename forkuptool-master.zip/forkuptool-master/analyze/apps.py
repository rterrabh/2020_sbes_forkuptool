from django.apps import AppConfig


class AnalyzeConfig(AppConfig):
    name = 'analyze'
