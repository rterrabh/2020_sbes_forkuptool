from django.apps import AppConfig


class ExecutionConfig(AppConfig):
    name = 'execution'
