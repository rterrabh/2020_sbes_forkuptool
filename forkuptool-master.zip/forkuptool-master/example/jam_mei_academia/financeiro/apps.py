from django.apps import AppConfig


class FinanceiroConfig(AppConfig):
    name = 'financeiro'
