from django.apps import AppConfig


class AlunosConfig(AppConfig):
    name = 'alunos'
