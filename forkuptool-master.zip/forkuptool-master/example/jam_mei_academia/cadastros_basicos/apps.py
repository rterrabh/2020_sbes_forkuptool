from django.apps import AppConfig


class CadastrosBasicosConfig(AppConfig):
    name = 'cadastros_basicos'
    verbose_name = 'Cadastros básicos'
